package sample05;

public interface OrderMessage {
	void getOrderMessage();
}
